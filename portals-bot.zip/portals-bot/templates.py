from html import escape

DEFAULT_TEMPLATES = {
"START_TEXT": "<b>Wᴇʟᴄᴏᴍᴇ ᴛᴏ {BOT_NAME}!\n\nYᴏᴜʀ ᴀɴɪᴍᴇ ʟɪʙʀᴀʀʏ sᴛᴀʀᴛs ʜᴇʀᴇ.\n\nCʜᴏᴏsᴇ ᴀɴ ᴏᴘᴛɪᴏɴ ʙᴇʟᴏᴡ ᴛᴏ ʟᴇᴀʀɴ ᴀʙᴏᴜᴛ ᴛʜᴇ ʙᴏᴛ, ᴠɪᴇᴡ ᴏᴜʀ ᴄʜᴀɴɴᴇʟs, ᴏʀ ɢᴇᴛ ʜᴇʟᴘ.</b>",
"ABOUT_TEXT": "Aʙᴏᴜᴛ {BOT_NAME}\n\nYᴏᴜʀ ᴀɴɪᴍᴇ ᴍᴇᴅɪᴀ ᴅᴇʟɪᴠᴇʀʏ ʙᴏᴛ.\n\nOᴡɴᴇʀ: {OWNER_USERNAME}",
"CHANNELS_TEXT": "Oᴜʀ ᴏғғɪᴄɪᴀʟ ᴄʜᴀɴɴᴇʟs:\n\n{CHANNEL_LINKS}",
"HELP_TEXT": "Nᴇᴇᴅ ʜᴇʟᴘ ᴜsɪɴɢ ᴛʜᴇ ʙᴏᴛ?\n\nRᴇᴀᴅ ᴛʜᴇ ɪɴsᴛʀᴜᴄᴛɪᴏɴs ᴏʀ ᴄᴏɴᴛᴀᴄᴛ ᴏᴜʀ sᴜᴘᴘᴏʀᴛ ɢʀᴏᴜᴘ:\n{SUPPORT_LINK}",
"FSUB_TEXT": "Pʟᴇᴀsᴇ Jᴏɪɴ ᴀʟʟ ʀᴇǫᴜɪʀᴇᴅ ᴄʜᴀɴɴᴇʟs ᴛᴏ ᴄᴏɴᴛɪɴᴜᴇ.\n\nAғᴛᴇʀ Jᴏɪɴɪɴɢ, ᴘʀᴇss Cʜᴇᴄᴋ Aɢᴀɪɴ ᴛᴏ ᴠᴇʀɪғʏ ʏᴏᴜʀ ᴍᴇᴍʙᴇʀsʜɪᴘ.\n\n{CHANNEL_LIST}",
"ANIME_ACCESS_TEXT": "Yᴏᴜʀ ʀᴇǫᴜᴇsᴛᴇᴅ ᴀɴɪᴍᴇ ᴄᴏʟʟᴇᴄᴛɪᴏɴ ɪs ʀᴇᴀᴅʏ.\n\nUsᴇ ᴛʜᴇ ʙᴜᴛᴛᴏɴ ʙᴇʟᴏᴡ ᴛᴏ ᴏᴘᴇɴ ᴛʜᴇ ᴀᴠᴀɪʟᴀʙʟᴇ ᴄᴏʟʟᴇᴄᴛɪᴏɴ.\n\nTʜɪs ᴀᴄᴄᴇss ʟɪɴᴋ ᴇxᴘɪʀᴇs ᴀғᴛᴇʀ {EXPIRY_TIME}.",
"FILE_TEXT": "<blockquote>{ORIGINAL_FILE_NAME}</blockquote>\n\nFɪʟᴇ ᴅᴇʟɪᴠᴇʀʏ ɪs ᴛᴇᴍᴘᴏʀᴀʀʏ. Tʜɪs ᴍᴇssᴀɢᴇ ᴡɪʟʟ ʙᴇ ᴅᴇʟᴇᴛᴇᴅ ᴀғᴛᴇʀ {DELETE_TIME} ᴍɪɴᴜᴛᴇs.",
"FILE_DELETED_TEXT": "Yᴏᴜʀ ᴅᴇʟɪᴠᴇʀᴇᴅ ғɪʟᴇ ᴍᴇssᴀɢᴇ ʜᴀs ʙᴇᴇɴ ᴅᴇʟᴇᴛᴇᴅ ᴀᴜᴛᴏᴍᴀᴛɪᴄᴀʟʟʏ.\n\nYᴏᴜ ᴍᴀʏ ʀᴇǫᴜᴇsᴛ ᴛʜᴇ ғɪʟᴇ ᴀɢᴀɪɴ ᴜsɪɴɢ ᴛʜᴇ ʙᴜᴛᴛᴏɴ ʙᴇʟᴏᴡ, sᴜʙJᴇᴄᴛ ᴛᴏ ʏᴏᴜʀ ʀᴇɢᴀɪɴ ʟɪᴍɪᴛ.",
"EXPIRED_TEXT": "Tʜɪs ᴀᴄᴄᴇss ʟɪɴᴋ ʜᴀs ᴇxᴘɪʀᴇᴅ.\n\nRᴇᴛᴜʀɴ ᴛᴏ ᴛʜᴇ ᴍᴀɪɴ ᴀɴɪᴍᴇ ᴅɪʀᴇᴄᴛᴏʀʏ ᴀɴᴅ ᴏᴘᴇɴ ᴛʜᴇ ᴀɴɪᴍᴇ ʟɪɴᴋ ᴀɢᴀɪɴ ᴛᴏ ʀᴇǫᴜᴇsᴛ ғʀᴇsʜ ᴀᴄᴄᴇss.",
"PREMIUM_TEXT": "Pʀᴇᴍɪᴜᴍ ᴍᴇᴍʙᴇʀsʜɪᴘ ʀᴇǫᴜɪʀᴇᴅ.\n\nTʜɪs ᴄᴏʟʟᴇᴄᴛɪᴏɴ ɪs ᴀᴠᴀɪʟᴀʙʟᴇ ᴛᴏ ᴀᴄᴛɪᴠᴇ ᴘʀᴇᴍɪᴜᴍ ᴍᴇᴍʙᴇʀs ᴏɴʟʏ.\n\nFᴏʀ ᴘᴀʏᴍᴇɴᴛ ᴀɴᴅ ᴀᴄᴛɪᴠᴀᴛɪᴏɴ ᴅᴇᴛᴀɪʟs, ᴄᴏɴᴛᴀᴄᴛ ᴛʜᴇ ᴏᴡɴᴇʀ.",
"PREMIUM_EXPIRY_TEXT": "A ᴜsᴇʀ's ᴘʀᴇᴍɪᴜᴍ ᴍᴇᴍʙᴇʀsʜɪᴘ ʜᴀs ᴇxᴘɪʀᴇᴅ.\n\nUsᴇʀ: {USER_ID}\nExᴘɪʀᴇᴅ ᴀᴛ: {EXPIRY_DATE}",
"FALLBACK_TEXT": "Sᴏᴍᴇᴛʜɪɴɢ ᴡᴇɴᴛ ᴡʀᴏɴɢ ᴡʜɪʟᴇ ᴘʀᴏᴄᴇssɪɴɢ ʏᴏᴜʀ ʀᴇǫᴜᴇsᴛ.\n\nPʟᴇᴀsᴇ ᴛʀʏ ᴀɢᴀɪɴ ʟᴀᴛᴇʀ ᴏʀ ᴄᴏɴᴛᴀᴄᴛ sᴜᴘᴘᴏʀᴛ ɪғ ᴛʜᴇ ɪssᴜᴇ ᴄᴏɴᴛɪɴᴜᴇs.",
}

def render_template(key, **kwargs):
    template = DEFAULT_TEMPLATES.get(key, key)
    # Only substitute explicitly supplied placeholders. Escape values before HTML parsing.
    safe = {k: escape(str(v)) for k, v in kwargs.items()}
    try: return template.format_map(_SafeDict(safe))
    except Exception: return template

class _SafeDict(dict):
    def __missing__(self, key): return "{" + key + "}"
