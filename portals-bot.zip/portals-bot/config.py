import os

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
DATABASE_URL = os.getenv("DATABASE_URL", "")
OWNER_ID = int(os.getenv("OWNER_ID", "8043083450"))
OWNER_USERNAME = os.getenv("OWNER_USERNAME", "@your_owner_username")
BOT_NAME = os.getenv("BOT_NAME", "Portals Bot")
REPOSITORY_CHAT_ID = os.getenv("REPOSITORY_CHAT_ID", "")
DEFAULT_LINK_EXPIRY_MINUTES = int(os.getenv("DEFAULT_LINK_EXPIRY_MINUTES", "3"))
DEFAULT_AUTO_DELETE_MINUTES = int(os.getenv("DEFAULT_AUTO_DELETE_MINUTES", "10"))
DEFAULT_MAX_REGAINS = int(os.getenv("DEFAULT_MAX_REGAINS", "3"))
