# Portals Bot

Telegram anime collection delivery bot scaffold. Repository visibility should be set to **Private**.

## Features in this initial implementation
- PostgreSQL persistence (Neon-compatible)
- `/upload Collection title` → send media in order → `/finish`
- Saves incoming media messages to a private Telegram repository channel
- Generates expiring Telegram deep links for collections
- Start/About/Channels/Help messages and owner-editable basic settings
- Manual premium activation (`/premium USER_ID 7|30|90|365`)
- Trusted admin role storage (`/addadmin USER_ID uploads,user_management,support_logs`)
- User block/unblock, basic broadcast, collection-to-directory post mapping
- Scheduled per-message deletion and regain button
- Render web health endpoint

## Important implementation status
This is a **starter implementation**, not yet the complete specification. Before public production use, complete and test: six-channel forced subscription, fully featured scheduled/recurring media broadcasts, premium expiry notifications and premium-only collection creation UI, complete token renewal/mapping controls, robust regain association for duplicate filenames, detailed permission enforcement on every command, external backups/restore automation, error handling, and per-action rate limits. Do not advertise those as active until implemented and tested.

## Deploy
1. Create a **private** GitHub repository named `portals-bot`.
2. Upload these files to its root.
3. In Render, create a Web Service from the private repository.
4. Set environment variables: `TELEGRAM_BOT_TOKEN`, `DATABASE_URL`, `OWNER_ID`, `OWNER_USERNAME`, `BOT_NAME`, and `REPOSITORY_CHAT_ID`.
5. Add the bot as an administrator in the private repository channel with permission to post messages.
6. Start the service and check `/health`.

Use the pooled Neon PostgreSQL connection string as `DATABASE_URL`. Keep it secret. If connection errors mention channel binding, copy the connection string directly from Neon and do not manually edit its parameters.

## Commands currently implemented
- `/start`
- `/upload Collection title`
- `/finish`
- `/settings`
- `/addadmin USER_ID uploads,user_management,support_logs`
- `/setstart TEXT`
- `/setabout TEXT`
- `/setchannels LINKS`
- `/sethelp LINK`
- `/setrepository CHAT_ID`
- `/setdirectory CHAT_ID`
- `/setfsub` (intentionally disabled placeholder)
- `/maplink DIRECTORY_CHAT_ID MESSAGE_ID COLLECTION_ID`
- `/premium USER_ID 7|30|90|365`
- `/block USER_ID`
- `/unblock USER_ID`
- `/broadcast MESSAGE`

## Security notes
- Never commit `.env`, a bot token, a database URL, or passwords.
- Only use media you have rights to distribute.
- Telegram cannot delete copies a user has already downloaded or saved.
- A bot can only copy repository messages if it has access to the source channel.
