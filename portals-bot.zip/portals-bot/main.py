import asyncio, logging, os, secrets, string, time
from datetime import datetime, timezone, timedelta
from aiohttp import web
import asyncpg
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.constants import ParseMode
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, ContextTypes, filters

from config import *
from templates import DEFAULT_TEMPLATES, render_template

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("portals-bot")
pool = None
upload_sessions = {}
user_last_action = {}

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS users (user_id BIGINT PRIMARY KEY, username TEXT, first_name TEXT, started_at TIMESTAMPTZ DEFAULT now(), is_blocked BOOLEAN DEFAULT false);
CREATE TABLE IF NOT EXISTS admins (user_id BIGINT PRIMARY KEY, permissions TEXT[] NOT NULL DEFAULT '{}');
CREATE TABLE IF NOT EXISTS collections (id BIGSERIAL PRIMARY KEY, title TEXT NOT NULL, is_premium BOOLEAN DEFAULT false, created_by BIGINT, created_at TIMESTAMPTZ DEFAULT now(), active BOOLEAN DEFAULT true);
CREATE TABLE IF NOT EXISTS collection_items (id BIGSERIAL PRIMARY KEY, collection_id BIGINT REFERENCES collections(id) ON DELETE CASCADE, position INT NOT NULL, repository_chat_id BIGINT, repository_message_id BIGINT, file_id TEXT, file_name TEXT, media_type TEXT, caption TEXT, UNIQUE(collection_id, position));
CREATE TABLE IF NOT EXISTS access_tokens (token TEXT PRIMARY KEY, collection_id BIGINT REFERENCES collections(id) ON DELETE CASCADE, created_by BIGINT, expires_at TIMESTAMPTZ NOT NULL, active BOOLEAN DEFAULT true);
CREATE TABLE IF NOT EXISTS deliveries (id BIGSERIAL PRIMARY KEY, user_id BIGINT, collection_id BIGINT, delivered_chat_id BIGINT, delivered_message_id BIGINT, file_name TEXT, sent_at TIMESTAMPTZ DEFAULT now(), deleted_at TIMESTAMPTZ, regain_count INT DEFAULT 0);
CREATE TABLE IF NOT EXISTS premium_members (user_id BIGINT PRIMARY KEY, expires_at TIMESTAMPTZ NOT NULL, activated_by BIGINT, updated_at TIMESTAMPTZ DEFAULT now());
CREATE TABLE IF NOT EXISTS broadcast_jobs (id BIGSERIAL PRIMARY KEY, audience TEXT NOT NULL, payload JSONB NOT NULL, run_at TIMESTAMPTZ NOT NULL, recurrence TEXT, status TEXT DEFAULT 'pending', created_by BIGINT);
CREATE TABLE IF NOT EXISTS audit_logs (id BIGSERIAL PRIMARY KEY, actor_id BIGINT, action TEXT NOT NULL, details JSONB DEFAULT '{}', created_at TIMESTAMPTZ DEFAULT now());
CREATE TABLE IF NOT EXISTS backup_runs (id BIGSERIAL PRIMARY KEY, destination TEXT, status TEXT, details TEXT, created_at TIMESTAMPTZ DEFAULT now());
CREATE TABLE IF NOT EXISTS directory_mappings (id BIGSERIAL PRIMARY KEY, directory_chat_id BIGINT, directory_message_id BIGINT, collection_id BIGINT REFERENCES collections(id), token TEXT, created_at TIMESTAMPTZ DEFAULT now());
"""

def is_owner(uid): return uid == OWNER_ID

async def setting(key, default=""):
    async with pool.acquire() as c:
        row = await c.fetchrow("SELECT value FROM settings WHERE key=$1", key)
        return row["value"] if row else default

async def set_setting(key, value):
    async with pool.acquire() as c:
        await c.execute("INSERT INTO settings(key,value) VALUES($1,$2) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value", key, value)

async def audit(actor, action, details="{}"):
    async with pool.acquire() as c:
        await c.execute("INSERT INTO audit_logs(actor_id,action,details) VALUES($1,$2,$3::jsonb)", actor, action, details)

async def user_upsert(user):
    async with pool.acquire() as c:
        await c.execute("""INSERT INTO users(user_id,username,first_name) VALUES($1,$2,$3)
        ON CONFLICT(user_id) DO UPDATE SET username=EXCLUDED.username,first_name=EXCLUDED.first_name""",
        user.id, user.username or "", user.first_name or "")

async def cooldown(update, context, action, seconds=2):
    uid = update.effective_user.id
    now = time.monotonic()
    key = (uid, action)
    last = user_last_action.get(key, 0)
    if now-last < seconds:
        if update.effective_message: await update.effective_message.reply_text("Please wait a moment before trying again.")
        return True
    user_last_action[key] = now
    return False

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    await user_upsert(u)
    if context.args:
        payload = context.args[0]
        if payload.startswith("a_"):
            token = payload[2:]
            async with pool.acquire() as c:
                row = await c.fetchrow("""SELECT t.*, c.title,c.is_premium,c.id AS cid FROM access_tokens t
                    JOIN collections c ON c.id=t.collection_id WHERE t.token=$1 AND t.active=true AND c.active=true""", token)
            if not row or row["expires_at"] < datetime.now(timezone.utc):
                await update.effective_message.reply_text(await setting("EXPIRED_TEXT", render_template("EXPIRED_TEXT")))
                return
            if row["is_premium"]:
                async with pool.acquire() as c:
                    p = await c.fetchrow("SELECT expires_at FROM premium_members WHERE user_id=$1", u.id)
                if not p or p["expires_at"] < datetime.now(timezone.utc):
                    await update.effective_message.reply_text(await setting("PREMIUM_TEXT", render_template("PREMIUM_TEXT")))
                    return
            kb = InlineKeyboardMarkup([[InlineKeyboardButton("Open collection", callback_data=f"open:{row['cid']}:{token}")]])
            await update.effective_message.reply_text(
                await setting("ANIME_ACCESS_TEXT", render_template("ANIME_ACCESS_TEXT", EXPIRY_TIME="configured duration")),
                reply_markup=kb)
            return
    kb = InlineKeyboardMarkup([[
        InlineKeyboardButton("About", callback_data="page:ABOUT_TEXT"),
        InlineKeyboardButton("Channels", callback_data="page:CHANNELS_TEXT"),
        InlineKeyboardButton("Help", callback_data="page:HELP_TEXT")
    ]])
    await update.effective_message.reply_text(await setting("START_TEXT", render_template("START_TEXT", BOT_NAME=BOT_NAME)),
        reply_markup=kb, parse_mode=ParseMode.HTML)

async def page_callback(update, context):
    q = update.callback_query
    await q.answer()
    if q.data.startswith("page:"):
        key = q.data.split(":",1)[1]
        defaults = {"ABOUT_TEXT": {"OWNER_USERNAME": await setting("OWNER_USERNAME", OWNER_USERNAME)},
                    "CHANNELS_TEXT": {"CHANNEL_LINKS": await setting("CHANNEL_LINKS", "Not configured yet.")},
                    "HELP_TEXT": {"SUPPORT_LINK": await setting("SUPPORT_LINK", "Not configured yet.")}}
        await q.message.reply_text(await setting(key, render_template(key, BOT_NAME=BOT_NAME, **defaults.get(key, {}))), parse_mode=ParseMode.HTML)
    elif q.data.startswith("open:"):
        _, cid, token = q.data.split(":")
        async with pool.acquire() as c:
            row = await c.fetchrow("SELECT expires_at,active FROM access_tokens WHERE token=$1 AND collection_id=$2", token, int(cid))
            items = await c.fetch("SELECT * FROM collection_items WHERE collection_id=$1 ORDER BY position", int(cid))
        if not row or not row["active"] or row["expires_at"] < datetime.now(timezone.utc):
            await q.message.reply_text(await setting("EXPIRED_TEXT", render_template("EXPIRED_TEXT")))
            return
        await deliver_collection(context, q.from_user.id, int(cid), items)

async def deliver_collection(context, user_id, collection_id, items):
    if not items:
        await context.bot.send_message(user_id, "This collection has no files yet.")
        return
    for item in items:
        try:
            # Repository messages are copied so the user receives the original media/caption.
            msg = await context.bot.copy_message(chat_id=user_id, from_chat_id=item["repository_chat_id"],
                                                 message_id=item["repository_message_id"],
                                                 caption=render_template("FILE_TEXT", ORIGINAL_FILE_NAME=item["file_name"] or "File"),
                                                 parse_mode=ParseMode.HTML)
            async with pool.acquire() as c:
                await c.execute("""INSERT INTO deliveries(user_id,collection_id,delivered_chat_id,delivered_message_id,file_name)
                    VALUES($1,$2,$3,$4,$5)""", user_id, collection_id, user_id, msg.message_id, item["file_name"] or "")
        except Exception:
            log.exception("Delivery failed for user %s item %s", user_id, item["id"])
            await audit(user_id, "delivery_error", '{"collection_id": %s}' % collection_id)
    await context.bot.send_message(user_id, "Delivery complete. Messages are scheduled for temporary deletion.")

async def upload_cmd(update, context):
    uid = update.effective_user.id
    if not is_owner(uid) and not await has_permission(uid, "uploads"):
        await update.effective_message.reply_text("Owner/admin permission required.")
        return
    if not context.args:
        await update.effective_message.reply_text("Usage: /upload Collection title")
        return
    title = " ".join(context.args)
    upload_sessions[uid] = {"title": title, "items": []}
    await update.effective_message.reply_text("Upload session started: %s\nSend files/messages in order, then use /finish." % title)

async def capture_upload(update, context):
    uid = update.effective_user.id
    if uid not in upload_sessions or not update.effective_message:
        return
    msg = update.effective_message
    media = msg.document or msg.video or msg.audio or msg.animation or (msg.photo[-1] if msg.photo else None)
    if not media:
        await msg.reply_text("Send a document, video, audio, animation, or photo in this upload session.")
        return
    name = getattr(media, "file_name", None) or ("photo_%s" % (len(upload_sessions[uid]["items"]) + 1))
    # Save original message into private repository. Telegram's copy_message preserves source media/caption.
    if not REPOSITORY_CHAT_ID:
        await msg.reply_text("Repository is not configured. Owner must run /setrepository CHAT_ID.")
        return
    saved = await context.bot.copy_message(chat_id=REPOSITORY_CHAT_ID, from_chat_id=msg.chat_id, message_id=msg.message_id)
    upload_sessions[uid]["items"].append({"repository_chat_id": REPOSITORY_CHAT_ID, "repository_message_id": saved.message_id,
                                          "file_id": media.file_id, "file_name": name, "caption": msg.caption or ""})
    await msg.reply_text("Added #%d: %s" % (len(upload_sessions[uid]["items"]), name))

async def finish_upload(update, context):
    uid = update.effective_user.id
    session = upload_sessions.get(uid)
    if not session:
        await update.effective_message.reply_text("No upload session. Start with /upload Collection title.")
        return
    if not session["items"]:
        await update.effective_message.reply_text("No files received; session remains open.")
        return
    async with pool.acquire() as c:
        cid = await c.fetchval("INSERT INTO collections(title,created_by) VALUES($1,$2) RETURNING id", session["title"], uid)
        for pos, item in enumerate(session["items"], 1):
            await c.execute("""INSERT INTO collection_items(collection_id,position,repository_chat_id,repository_message_id,file_id,file_name,media_type,caption)
                VALUES($1,$2,$3,$4,$5,$6,$7,$8)""", cid, pos, item["repository_chat_id"], item["repository_message_id"],
                item["file_id"], item["file_name"], "media", item["caption"])
    token = secrets.token_urlsafe(9).replace("-", "").replace("_", "")[:12]
    expiry_minutes = int(await setting("LINK_EXPIRY_MINUTES", str(DEFAULT_LINK_EXPIRY_MINUTES)))
    async with pool.acquire() as c:
        await c.execute("INSERT INTO access_tokens(token,collection_id,created_by,expires_at) VALUES($1,$2,$3,$4)",
                        token, cid, uid, datetime.now(timezone.utc)+timedelta(minutes=expiry_minutes))
    del upload_sessions[uid]
    await audit(uid, "collection_created", '{"collection_id": %d}' % cid)
    me = await context.bot.get_me()
    link = f"https://t.me/{me.username}?start=a_{token}"
    await update.effective_message.reply_text(f"Collection saved: {session['title']}\nFiles: {len(session['items'])}\nAccess link (expires in {expiry_minutes} min):\n{link}\n\nUse /maplink <directory_chat_id> <directory_message_id> {cid} to map an existing directory post.")

async def has_permission(uid, permission):
    async with pool.acquire() as c:
        row = await c.fetchrow("SELECT permissions FROM admins WHERE user_id=$1", uid)
    return bool(row and permission in row["permissions"])

async def admin_add(update, context):
    if not is_owner(update.effective_user.id): return
    if len(context.args) < 2:
        await update.effective_message.reply_text("Usage: /addadmin USER_ID uploads,user_management,support_logs")
        return
    try: target = int(context.args[0])
    except ValueError:
        await update.effective_message.reply_text("User ID must be numeric."); return
    perms = [x.strip() for x in context.args[1].split(",") if x.strip() in {"uploads","user_management","support_logs"}]
    async with pool.acquire() as c:
        await c.execute("INSERT INTO admins(user_id,permissions) VALUES($1,$2) ON CONFLICT(user_id) DO UPDATE SET permissions=EXCLUDED.permissions", target, perms)
    await audit(update.effective_user.id, "admin_permissions_updated", '{"target": %d}' % target)
    await update.effective_message.reply_text("Trusted admin saved.")

async def settings_command(update, context):
    if not is_owner(update.effective_user.id):
        await update.effective_message.reply_text("Owner-only command."); return
    keys = ["OWNER_USERNAME","CHANNEL_LINKS","SUPPORT_LINK","DIRECTORY_CHAT_ID","REPOSITORY_CHAT_ID","LINK_EXPIRY_MINUTES","AUTO_DELETE_MINUTES","MAX_REGAINS"]
    async with pool.acquire() as c:
        rows = await c.fetch("SELECT key,value FROM settings WHERE key=ANY($1::text[])", keys)
    values = {r["key"]:r["value"] for r in rows}
    text = "Current settings:\n" + "\n".join(f"{k}: {values.get(k, '(not set)')}" for k in keys)
    await update.effective_message.reply_text(text)

async def setvalue(update, context, key, value):
    if not is_owner(update.effective_user.id):
        await update.effective_message.reply_text("Owner-only command."); return
    if not value:
        await update.effective_message.reply_text(f"Usage: /set{key.lower()} VALUE"); return
    await set_setting(key, value)
    await audit(update.effective_user.id, "setting_changed", '{"key":"%s"}' % key)
    await update.effective_message.reply_text(f"{key} updated.")

async def setstart(update, context): await setvalue(update, context, "START_TEXT", " ".join(context.args))
async def setabout(update, context): await setvalue(update, context, "ABOUT_TEXT", " ".join(context.args))
async def setchannels(update, context): await setvalue(update, context, "CHANNEL_LINKS", " ".join(context.args))
async def sethelp(update, context): await setvalue(update, context, "SUPPORT_LINK", " ".join(context.args))
async def setrepository(update, context): await setvalue(update, context, "REPOSITORY_CHAT_ID", " ".join(context.args))
async def setdirectory(update, context): await setvalue(update, context, "DIRECTORY_CHAT_ID", " ".join(context.args))
async def setfsub(update, context):
    await update.effective_message.reply_text("F-sub integration is intentionally not enabled yet, as requested.")

async def maplink(update, context):
    if not is_owner(update.effective_user.id):
        await update.effective_message.reply_text("Owner-only command."); return
    if len(context.args) != 3:
        await update.effective_message.reply_text("Usage: /maplink DIRECTORY_CHAT_ID MESSAGE_ID COLLECTION_ID"); return
    dchat, dmsg, cid = map(int, context.args)
    async with pool.acquire() as c:
        token = await c.fetchval("SELECT token FROM access_tokens WHERE collection_id=$1 AND active=true ORDER BY created_at DESC LIMIT 1", cid)
        if not token:
            await update.effective_message.reply_text("No active token for that collection."); return
        await c.execute("INSERT INTO directory_mappings(directory_chat_id,directory_message_id,collection_id,token) VALUES($1,$2,$3,$4)", dchat,dmsg,cid,token)
    await update.effective_message.reply_text("Directory post mapped.")

async def premium_cmd(update, context):
    if not is_owner(update.effective_user.id): return
    if len(context.args) != 2:
        await update.effective_message.reply_text("Usage: /premium USER_ID 7|30|90|365"); return
    uid, days = int(context.args[0]), int(context.args[1])
    if days not in (7,30,90,365):
        await update.effective_message.reply_text("Duration must be 7, 30, 90, or 365 days."); return
    expires = datetime.now(timezone.utc)+timedelta(days=days)
    async with pool.acquire() as c:
        await c.execute("INSERT INTO premium_members(user_id,expires_at,activated_by) VALUES($1,$2,$3) ON CONFLICT(user_id) DO UPDATE SET expires_at=EXCLUDED.expires_at,activated_by=EXCLUDED.activated_by,updated_at=now()", uid,expires,update.effective_user.id)
    await audit(update.effective_user.id, "premium_activated", '{"user_id": %d, "days": %d}' % (uid,days))
    await update.effective_message.reply_text(f"Premium activated for {uid} until {expires.isoformat()}")

async def blockuser(update, context):
    if not is_owner(update.effective_user.id) and not await has_permission(update.effective_user.id, "user_management"):
        await update.effective_message.reply_text("Permission required."); return
    if len(context.args) != 1:
        await update.effective_message.reply_text("Usage: /block USER_ID"); return
    async with pool.acquire() as c: await c.execute("UPDATE users SET is_blocked=true WHERE user_id=$1", int(context.args[0]))
    await update.effective_message.reply_text("User blocked if present in database.")

async def unblockuser(update, context):
    if not is_owner(update.effective_user.id) and not await has_permission(update.effective_user.id, "user_management"):
        await update.effective_message.reply_text("Permission required."); return
    if len(context.args) != 1:
        await update.effective_message.reply_text("Usage: /unblock USER_ID"); return
    async with pool.acquire() as c: await c.execute("UPDATE users SET is_blocked=false WHERE user_id=$1", int(context.args[0]))
    await update.effective_message.reply_text("User unblocked if present in database.")

async def delete_expired(context):
    minutes = int(await setting("AUTO_DELETE_MINUTES", str(DEFAULT_AUTO_DELETE_MINUTES)))
    cutoff = datetime.now(timezone.utc)-timedelta(minutes=minutes)
    async with pool.acquire() as c:
        rows = await c.fetch("SELECT * FROM deliveries WHERE deleted_at IS NULL AND sent_at <= $1", cutoff)
    for row in rows:
        try:
            await context.bot.delete_message(row["delivered_chat_id"], row["delivered_message_id"])
            async with pool.acquire() as c:
                await c.execute("UPDATE deliveries SET deleted_at=now() WHERE id=$1", row["id"])
            kb = InlineKeyboardMarkup([[InlineKeyboardButton("Regain File", callback_data=f"regain:{row['id']}")]])
            await context.bot.send_message(row["user_id"], await setting("FILE_DELETED_TEXT", render_template("FILE_DELETED_TEXT")), reply_markup=kb)
        except Exception as e:
            log.warning("Auto-delete failed: %s", e)

async def regain_callback(update, context):
    q=update.callback_query; await q.answer()
    did=int(q.data.split(":")[1])
    async with pool.acquire() as c:
        row=await c.fetchrow("""SELECT d.*,i.repository_chat_id,i.repository_message_id,i.file_name FROM deliveries d
            JOIN collection_items i ON i.collection_id=d.collection_id AND i.file_name=d.file_name
            WHERE d.id=$1 AND d.user_id=$2""", did, q.from_user.id)
    if not row:
        await q.message.reply_text("This file cannot be restored."); return
    max_regains=int(await setting("MAX_REGAINS", str(DEFAULT_MAX_REGAINS)))
    if row["regain_count"]>=max_regains:
        await q.message.reply_text("Your regain limit has been reached."); return
    try:
        msg=await context.bot.copy_message(chat_id=q.from_user.id,from_chat_id=row["repository_chat_id"],message_id=row["repository_message_id"])
        async with pool.acquire() as c:
            await c.execute("UPDATE deliveries SET regain_count=regain_count+1 WHERE id=$1", did)
            await c.execute("INSERT INTO deliveries(user_id,collection_id,delivered_chat_id,delivered_message_id,file_name,regain_count) VALUES($1,$2,$3,$4,$5,1)",q.from_user.id,row["collection_id"],q.from_user.id,msg.message_id,row["file_name"])
    except Exception:
        await q.message.reply_text("Could not regain this file. Please contact support.")

async def broadcast(update, context):
    if not is_owner(update.effective_user.id):
        await update.effective_message.reply_text("Owner-only command."); return
    if not context.args:
        await update.effective_message.reply_text("Usage: /broadcast MESSAGE"); return
    body=" ".join(context.args)
    async with pool.acquire() as c: users=await c.fetch("SELECT user_id FROM users WHERE is_blocked=false")
    sent=failed=0
    for row in users:
        try: await context.bot.send_message(row["user_id"], body); sent+=1
        except Exception: failed+=1
        await asyncio.sleep(0.05)
    await audit(update.effective_user.id, "broadcast_complete", '{"sent": %d, "failed": %d}'%(sent,failed))
    await update.effective_message.reply_text(f"Broadcast finished. Sent: {sent}; failed: {failed}")

async def post_init(app):
    global pool
    pool = await asyncpg.create_pool(DATABASE_URL, min_size=1, max_size=5, command_timeout=30)
    async with pool.acquire() as c:
        await c.execute(SCHEMA)
        for key, value in DEFAULT_TEMPLATES.items():
            await c.execute("INSERT INTO settings(key,value) VALUES($1,$2) ON CONFLICT(key) DO NOTHING", key, value)
        await c.execute("INSERT INTO settings(key,value) VALUES('OWNER_USERNAME',$1) ON CONFLICT(key) DO NOTHING", OWNER_USERNAME)
        await c.execute("INSERT INTO settings(key,value) VALUES('REPOSITORY_CHAT_ID',$1) ON CONFLICT(key) DO NOTHING", str(REPOSITORY_CHAT_ID or ""))
        await c.execute("INSERT INTO admins(user_id,permissions) VALUES($1,$2) ON CONFLICT(user_id) DO NOTHING", OWNER_ID, ["uploads","user_management","support_logs","premium","broadcast","config"])
    app.job_queue.run_repeating(delete_expired, interval=30, first=30, name="auto-delete")
    log.info("Database initialized")

async def health(request): return web.Response(text="portals-bot is running")

async def run_health_server():
    app=web.Application(); app.router.add_get("/",health); app.router.add_get("/health",health)
    runner=web.AppRunner(app); await runner.setup()
    site=web.TCPSite(runner,"0.0.0.0",int(os.getenv("PORT","10000"))); await site.start()
    return runner

def main():
    if not BOT_TOKEN or not DATABASE_URL:
        raise RuntimeError("Set TELEGRAM_BOT_TOKEN and DATABASE_URL environment variables.")
    app = Application.builder().token(BOT_TOKEN).post_init(post_init).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("upload", upload_cmd))
    app.add_handler(CommandHandler("finish", finish_upload))
    app.add_handler(CommandHandler("settings", settings_command))
    app.add_handler(CommandHandler("addadmin", admin_add))
    app.add_handler(CommandHandler("setstart", setstart))
    app.add_handler(CommandHandler("setabout", setabout))
    app.add_handler(CommandHandler("setchannels", setchannels))
    app.add_handler(CommandHandler("sethelp", sethelp))
    app.add_handler(CommandHandler("setrepository", setrepository))
    app.add_handler(CommandHandler("setdirectory", setdirectory))
    app.add_handler(CommandHandler("setfsub", setfsub))
    app.add_handler(CommandHandler("maplink", maplink))
    app.add_handler(CommandHandler("premium", premium_cmd))
    app.add_handler(CommandHandler("block", blockuser))
    app.add_handler(CommandHandler("unblock", unblockuser))
    app.add_handler(CommandHandler("broadcast", broadcast))
    app.add_handler(CallbackQueryHandler(page_callback, pattern=r"^(page:|open:)"))
    app.add_handler(CallbackQueryHandler(regain_callback, pattern=r"^regain:"))
    app.add_handler(MessageHandler(filters.ChatType.PRIVATE & ~filters.COMMAND, capture_upload))
    async def runner():
        await app.initialize(); await app.start(); await app.updater.start_polling()
        health_runner=await run_health_server()
        try:
            while True: await asyncio.sleep(3600)
        finally:
            await app.updater.stop(); await app.stop(); await app.shutdown(); await health_runner.cleanup()
    asyncio.run(runner())

if __name__ == "__main__": main()
